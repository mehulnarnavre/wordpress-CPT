<?php
get_header();

$bookdata = get_queried_object();
print_r($bookdata);
?>
<h1></h1>
<?php
get_footer();


?>